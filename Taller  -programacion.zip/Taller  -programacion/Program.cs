﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1_Taller_programacion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;//cambia de color las letras
            Console.WriteLine(" +++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine(" Suma, promedio,maximo y menimo valor de un numero N");
            Console.WriteLine(" +++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("----------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;//cambia de color las letras
            Console.WriteLine(" ++++++++++++++++++++++");
            Console.WriteLine(" While - Do While - For");
            Console.WriteLine(" ++++++++++++++++++++++");
            Console.WriteLine();
            int N = 0;
            int suma = 0;//Acumulador
            int contador = 0;//contador
            int promedio = 0;
            int maximo = 0;
            int minimo = 0;
            minimo = int.MaxValue;
            maximo = int.MinValue;
            Console.Write(" Ingresar un numero = ");
            N = Int32.Parse(Console.ReadLine());
            Console.Clear();//Limpia la pantalla mostrada anterior para mostrar los de las lineas siguientes
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Blue;//cambia de color las letras
            Console.WriteLine(" ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine($" Calculo y Muestra de Resultados correspondientes al numero = {N} ");
            Console.WriteLine(" ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.ForegroundColor = ConsoleColor.White;//cambia de color las letras
            Console.WriteLine();
            /* for (int i = 1; i <= N; i++)
              {
                 suma += i;
                 contador++;
                  if (i > maximo)
                  {
                      maximo = contador;
                  }
                  if (i < minimo)
                  {
                      minimo = contador;
                  }
              }*/

            while (contador < N)
             {
                 contador++;
                 suma += contador;
                 
                 if (contador > maximo)
                 {
                     maximo = contador;
                 }
                 if (contador < minimo)
                 {
                     minimo = contador;
                 }
             }
            /*do {
                contador++;
                suma += contador;
               
                if (contador > maximo)
                {
                    maximo = contador;
                }
                if (contador < minimo)
                {
                    minimo = contador;
                }
            } while (contador!=N);*/


                        promedio = suma / contador;
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;//cambia de color las letras
            Console.WriteLine($" . Suma = {suma}");
            Console.ForegroundColor = ConsoleColor.Green;//cambia de color las letras
            Console.WriteLine($" . Promedio = {promedio}");
            Console.ForegroundColor = ConsoleColor.Yellow;//cambia de color las letras
            Console.WriteLine($" . Maximo = {maximo}");
            Console.ForegroundColor = ConsoleColor.Yellow;//cambia de color las letras
            Console.WriteLine($" . Minimo = {minimo}");
            Console.ForegroundColor = ConsoleColor.White;//cambia de color las letras
            Console.WriteLine();
            Console.WriteLine(" ****************");
            Console.WriteLine(" Fin  del proceso");
            Console.WriteLine(" ****************");
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
